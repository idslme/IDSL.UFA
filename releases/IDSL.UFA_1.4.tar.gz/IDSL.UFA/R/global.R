utils::globalVariables(c("counter", "UFA_memeory_variables", "k", "IUPAC_Isotopes", "mz", "int", "spectra_figure"))
