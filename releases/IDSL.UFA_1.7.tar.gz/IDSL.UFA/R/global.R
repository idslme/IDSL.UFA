utils::globalVariables(c("i", "k", "counter", "IUPAC_Isotopes", "MolecularFormula", "logIPA"))
