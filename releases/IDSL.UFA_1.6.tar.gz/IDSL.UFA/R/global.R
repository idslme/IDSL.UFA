utils::globalVariables(c("k", "i", "mz", "int", "spectra_figure", "counter", "IUPAC_Isotopes", "MolecularFormula", "logUFA"))
