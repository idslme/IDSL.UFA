utils::globalVariables(c("i", "k", "counter", "MolecularFormula", ".logIPA"))
